package BangunDatar;

public class Lingkaran {
  double r,K,L,phi = 3.14;
  
  void Keliling() {
    K = 2 * (phi * r);
    System.out.println("HASIL KELILING LINGKARAN ADALAH " + K);
  }
  
  void Luas() {
    L = phi * (r * r);
    System.out.println("HASIL LUAS LINGKARAN ADALAH " + L);
  }
}
