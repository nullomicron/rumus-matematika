package BangunDatar;

public class Trapesium {
  int t,sPanjang,sPendek,sMiring1,sMiring2,K,L;
  
  void Keliling() {
    K = sPanjang + sPendek + sMiring1 + sMiring2;
    System.out.println("HASIL KELILING TRAPESIUM ADALAH " + K);
  }
  
  void Luas() {
    L = (sPanjang + sPendek) * t / 2;
    System.out.println("HASIL LUAS TRAPESIUM ADALAH " + L);
  }
}
