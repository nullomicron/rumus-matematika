package BangunDatar;

public class JajarGenjang {
  int a,t,sm,K,L;
  
  void Keliling() {
    K = 2 * (a + sm);
    System.out.println("HASIL KELILING JAJAR GENJANG ADALAH " + K);
  }
  
  void Luas() {
    L = a * t;
    System.out.println("HASIL LUAS JAJAR GENJANG ADALAH " + L);
  }
}