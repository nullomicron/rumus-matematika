package BangunDatar;

public class BelahKetupat {
  int sisi,d1,d2,keliling,luas;
  
  void Keliling() {
    keliling = 4 * sisi;
    System.out.println("HASIL KELILING BELAH KETUPAT ADALAH " + keliling);
  }
  
  void Luas() {
    luas = (d1 * d2) / 2;
    System.out.println("HASIL LUAS BELAH KETUPAT ADALAH " + luas);
  }
}
