package BangunDatar;

public class LayangLayang {
  int d1,d2,sa,ss,K,L;
  
  void Keliling() {
    K = (sa * 2) + (ss * 2);
    System.out.println("HASIL KELILING LAYANG-LAYANG ADALAH " + K);
  }
  
  void Luas() {
    L = (d1 * d2) / 2;
    System.out.println("HASIL LUAS LAYANG-LAYANG ADALAH " + L);
  }
}
