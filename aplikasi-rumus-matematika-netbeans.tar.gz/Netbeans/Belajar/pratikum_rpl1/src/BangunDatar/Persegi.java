package BangunDatar;

public class Persegi {
  // Mendeklarasikan Variabel
  int s,K,L;
  
  
  // Membuat Method
  void Keliling() {
    K = 4 * s;
    System.out.println("HASIL KELILING PERSEGI ADALAH " + K);
  }
  
  void Luas() {
    L = s * s;
    System.out.println("HASIL LUAS PERSEGI ADALAH " + L);
  }
}
