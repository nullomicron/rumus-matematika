package BangunDatar;

public class PersegiPanjang {
  int p,l,K,L;
  
  void Keliling() {
    K = 2 * (p + l);
    System.out.println("HASIL KELILING PERSEGI PANJANG ADALAH " + K);
  }
  
  void Luas() {
    L = p * l;
    System.out.println("HASIL LUAS PERSEGI PANJANG ADALAH " + L);
  }
}
