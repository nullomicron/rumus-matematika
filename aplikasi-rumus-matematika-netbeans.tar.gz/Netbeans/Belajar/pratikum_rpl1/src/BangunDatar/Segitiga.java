package BangunDatar;

public class Segitiga {
  int a,t,sm,K,L;
  
  void Keliling() {
    K = a + t + sm;
    System.out.println("HASIL KELILING SEGITIGA ADALAH " + K);
  }
  
  void Luas() {
    L = (a * t) / 2;
    System.out.println("HASIL LUAS SEGITIGA ADALAH " + L);
  }
}