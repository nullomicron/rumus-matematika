package BangunDatar;

import java.util.Scanner;
import BangunRuang.*;

public class Output {

  public static void main(String[] args) {
    int pil1,pil2;
    
    Scanner keyboard = new Scanner(System.in);
      
    System.out.println("MASUKAN PILIHAN ANDA");
    System.out.println("====================");
    System.out.println("1. BANGUN DATAR");
    System.out.println("2. BANGUN RUANG");
    System.out.print("INPUT : ");
    
    pil1 = keyboard.nextInt();
    
    if (pil1 == 1) {
      System.out.println("SELAMAT DATANG DI APLIKASI BANGUN DATAR");
      System.out.println("=======================================");
      System.out.println("");

      System.out.println("SILAHKAN PILIH BANGUN DATAR : ");
      System.out.println("1. Persegi");
      System.out.println("2. Persegi Panjang");
      System.out.println("3. Segitiga");
      System.out.println("4. Jajar Genjang");
      System.out.println("5. Layang-Layang");
      System.out.println("6. Belah Ketupat");
      System.out.println("7. Lingkaran");
      System.out.println("8. Trapesium");

      System.out.print("INPUT : ");
      pil2 = keyboard.nextInt();




      // Membuat Objek
      Persegi p = new Persegi();

      PersegiPanjang pp = new PersegiPanjang();

      Segitiga s = new Segitiga();

      JajarGenjang j = new JajarGenjang();

      BelahKetupat b = new BelahKetupat();

      LayangLayang ll = new LayangLayang();

      Lingkaran l = new Lingkaran();

      Trapesium t = new Trapesium();



      // Melakukan Kondisi
      switch (pil2) {
        case 1:
          System.out.print("MASUKAN SISI : ");
          p.s = keyboard.nextInt();
          System.out.println("");
          
          p.Keliling();
          p.Luas();
          break;
        case 2:
          System.out.print("MASUKAN PANJANG : ");
          pp.p = keyboard.nextInt();
          System.out.print("MASUKAN LEBAR : ");
          pp.l = keyboard.nextInt();
          System.out.println("");
          
          pp.Keliling();
          pp.Luas();
          break;
        case 3:
          System.out.print("MASUKAN ALAS : ");
          s.a = keyboard.nextInt();
          System.out.print("MASUKAN TINGGI : ");
          s.t = keyboard.nextInt();
          System.out.print("MASUKAN SISI MIRING : ");
          s.sm = keyboard.nextInt();
          System.out.println("");
          
          s.Keliling();
          s.Luas();
          break;
        case 4:
          System.out.print("MASUKAN ALAS : ");
          j.a = keyboard.nextInt ();
          System.out.print("MASUKAN TINGGI : ");
          j.t = keyboard.nextInt();
          System.out.print("MASUKAN SISI MIRING : ");
          j.sm = keyboard.nextInt();
          System.out.println("");
          
          j.Keliling();
          j.Luas();
          break;
        case 5:
          System.out.print("MASUKAN DIAGONAL 1 : ");
          ll.d1 = keyboard.nextInt();
          System.out.print("MASUKAN DIAGONAL 2 : ");
          ll.d2 = keyboard.nextInt();
          System.out.print("MASUKAN SISI ATAS : ");
          ll.sa = keyboard.nextInt();
          System.out.print("MASUKAN SISI SAMPING : ");
          ll.ss = keyboard.nextInt();
          System.out.println("");

          l.Keliling();
          l.Luas();
          break;
        case 6:
          System.out.print("MASUKAN DIAGONAL 1 : ");
          b.d1 = keyboard.nextInt();
          System.out.print("MASUKAN DIAGONAL 2 : ");
          b.d2 = keyboard.nextInt();
          System.out.print("MASUKAN SISI : ");
          b.sisi = keyboard.nextInt();
          System.out.println("");

          b.Keliling();
          b.Luas();
          break;
        case 7:
          System.out.print("MASUKAN JARI JARI : ");
          l.r = keyboard.nextDouble();
          System.out.println("");

          l.Keliling();
          l.Luas();
          break;
        case 8:
          System.out.print("MASUKAN TINGGI : ");
          t.t = keyboard.nextInt();
          System.out.print("MASUKAN SISI PANJANG : ");
          t.sPanjang = keyboard.nextInt();
          System.out.print("MASUKAN SISI PENDEK : ");
          t.sPendek = keyboard.nextInt();
          System.out.print("MASUKAN SISI MIRING 1 : ");
          t.sMiring1 = keyboard.nextInt();
          System.out.print("MASUKAN SISI MIRING 2 : ");
          t.sMiring2 = keyboard.nextInt();
          System.out.println("");

          t.Keliling();
          t.Luas();
          break;
        default:
          System.out.println("ERROR!!");
          break;
      }
    }
    else {
      System.out.println("SELAMAT DATANG DI APLIKASI BANGUN RUANG");
      System.out.println("=======================================");
      System.out.println("");

      System.out.println("SILAHKAN PILIH BANGUN RUANG : ");
      System.out.println("1. KUBUS");
      System.out.println("2. BALOK");
      System.out.println("3. TABUNG");
      System.out.println("4. KERUCUT");
      System.out.println("5. LIMAS SEGITIGA");
      System.out.println("6. LIMAS SEGIEMPAT");
      System.out.println("7. PRISMA SEGITIGA");
      System.out.println("8. BOLA");

      System.out.print("INPUT : ");
      pil2 = keyboard.nextInt();
      
      Kubus kb = new Kubus();
      
      Balok bl = new Balok();
      
      Tabung tb = new Tabung();
      
      Kerucut k = new Kerucut();
      
      LimasSegitiga ls = new LimasSegitiga();
      
      LimasSegiempat lse = new LimasSegiempat();
      
      PrismaSegitiga ps = new PrismaSegitiga();
      
      Bola bol = new Bola();
      
      switch (pil2) {
        case 1:
          System.out.print("MASUKAN RUSUK : ");
          kb.s = keyboard.nextInt();
          System.out.println("");
          
          kb.Luas();
          kb.Volume();
          break;
        case 2:
          System.out.print("MASUKAN PANJANG : ");
          bl.p = keyboard.nextInt();
          System.out.print("MASUKAN LEBAR : ");
          bl.l = keyboard.nextInt();
          System.out.print("MASUKAN TINGGI : ");
          bl.t = keyboard.nextInt();
          System.out.println("");
          
          bl.Luas();
          bl.Volume();
          break;
        case 3:
          System.out.print("MASUKAN JARI-JARI : ");
          tb.r = keyboard.nextDouble();
          System.out.print("MASUKAN TINGGI : ");
          tb.t = keyboard.nextDouble();
          System.out.println("");
          
          tb.Luas();
          tb.Volume();
          break;
        case 4:
          System.out.print("MASUKAN JARI-JARI : ");
          k.r = keyboard.nextDouble();
          System.out.print("MASUKAN TINGGI : ");
          k.t = keyboard.nextDouble();
          System.out.print("MASUKAN GARIS PELUKIS : ");
          k.s = keyboard.nextDouble();
          System.out.println("");
          
          k.Luas();
          k.Volume();
          break;
        case 5:
          System.out.print("MASUKAN ALAS  : ");
          ls.a = keyboard.nextDouble();
          System.out.print("MASUKAN TINGGI : ");
          ls.t = keyboard.nextDouble();
          System.out.print("MASUKAN SISI : ");
          ls.b = keyboard.nextDouble();
          System.out.println("");
          
          ls.Luas();
          ls.Volume();
          break;
        case 6:
          System.out.print("MASUKAN PANJANG : ");
          lse.p = keyboard.nextDouble();
          System.out.print("MASUKAN LEBAR : ");
          lse.l = keyboard.nextDouble();
          System.out.print("MASUKAN TINGGI : ");
          lse.t = keyboard.nextDouble();
          System.out.println("");
          
          lse.Luas();
          lse.Volume();
          break;
        case 7:
          System.out.print("MASUKAN SISI A : ");
          ps.a = keyboard.nextDouble();
          System.out.print("MASUKAN SISI B : ");
          ps.b = keyboard.nextDouble();
          System.out.print("MASUKAN TINGGI : ");
          ps.t = keyboard.nextDouble();
          System.out.print("MASUKAN LUAS ALAS : ");
          ps.LA = keyboard.nextDouble();
          System.out.println("");
          
          ps.Luas();
          ps.Volume();
          break;
        case 8:
          System.out.print("MASUKAN JARI JARI : ");
          bol.r = keyboard.nextDouble();
          System.out.println("");
          
          bol.Luas();
          bol.Volume();
          break;
        default:
          System.out.println("ERROR!");
          break;
      }
    }
  }
}
