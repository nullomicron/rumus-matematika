package BangunRuang;

public class LimasSegitiga {
  public double a,b,t,L,V,LA,LS;
  
 public void Luas() {
   LA = a * a;
   LS = (a * t / 2) * 4;
   L = LA + LS;
   System.out.println("HASIL LUAS PERMUKAAN LIMAS SEGITIGA ADALAH " + L);
 }
  
  public void Volume() {
    V = 0.33 * (a * b / 2) * t;
    System.out.println("HASIL VOLUME LIMAS SEGITIGA ADALAH " + V);
  }
}
