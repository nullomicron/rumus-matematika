package BangunRuang;

public class PrismaSegitiga {
  public double a,b,t,L,V,KA,LA;
  
  public void Luas() {
    KA = a + a + a;
    L = (KA * t) + (2 * LA);
    System.out.println("HASIL LUAS PERMUKAAN PRISMA SEGITIGA ADALAH " + L);
  }
  
  public void Volume() {
    V = a * b * t / 2;
    System.out.println("HASIL VOLUME PRISMA SEGITGA ADALAH " + V);
  }
}
