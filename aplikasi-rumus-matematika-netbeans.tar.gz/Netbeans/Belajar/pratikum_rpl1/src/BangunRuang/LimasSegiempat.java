package BangunRuang;

public class LimasSegiempat {
  public double p,l,t,L,V,LA,KL;
  
  public void Luas() {
    LA = p * l;
    KL = 2 * (p + l);
    L = 2 * (LA + KL) * t;
    System.out.println("HASIL LUAS PERMUKAAN SEGIEMPAT ADLAH " + L);
  }
  
  public void Volume() {
    V = 0.33 * (p * l) * t;
    System.out.println("HASIl VOLUME LIMAS SEGIEMPAT ADALAH " + V);
  }
}
