package BangunRuang;

public class Bola {
  public double r,L,V,phi = 3.14;
  
  public void Luas() {
    L = 4 * phi * r * r;
    System.out.println("HASIL LUAS PERMUKAAN BOLA ADALAH " + L);
  }
  
  public void Volume() {
    V = 1.33 * phi * r * r * r;
    System.out.println("HASIL VOLUME BOLA ADALAH " + V);
  }
}
