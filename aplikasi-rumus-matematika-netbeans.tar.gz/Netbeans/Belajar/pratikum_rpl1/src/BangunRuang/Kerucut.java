package BangunRuang;

public class Kerucut {
  public double r,t,s,K,LP,LS,V,phi = 3.14;
  
  public void Luas() {
    LP = phi * r * (r + s);
    System.out.println("HASIL LUAS PERMUKAAN KERUCUT ADALAH " + LP);
  }
  
  public void Volume() {
    V = (phi * r * r * t) / 2;
    System.out.println("HASIL VOLUME KERUCUT ADALAH " + V);
  }
}
