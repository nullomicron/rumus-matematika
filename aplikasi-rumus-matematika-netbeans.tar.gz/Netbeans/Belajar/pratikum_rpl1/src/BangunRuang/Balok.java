package BangunRuang;

public class Balok {
  public int p,l,t,L,V;
  
  public void Luas() {
    L = (2 * p * l) + (2 * p * t) + (2 * l * t);
    System.out.println("HASIL LUAS PERMUKAAN BALOK ADALAH " + L);
  }
  
  public void Volume() {
    V = p * l * t;
    System.out.println("HASIL VOLUME BALOK ADALAH " + V);
  }
}
