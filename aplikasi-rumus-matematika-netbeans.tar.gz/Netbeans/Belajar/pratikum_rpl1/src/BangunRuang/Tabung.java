package BangunRuang;

public class Tabung {
  public double r,t,L,V,phi = 3.14;
  
  public void Luas() {
    L = (2 * phi * r * r) + (2 * phi * r);
    System.out.println("HASIL LUAS PERMUKAAN TABUNG ADALAH " + L);
  }
  
  public void Volume() {
    V = phi * r * r * t;
    System.out.println("HASIL VOLUME TABUNG ADALAH " + V);
  }
}
