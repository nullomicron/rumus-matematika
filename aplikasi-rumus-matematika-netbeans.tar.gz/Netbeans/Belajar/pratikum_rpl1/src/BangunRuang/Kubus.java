package BangunRuang;

public class Kubus {
  public int s,L,V;
  
  public void Luas() {
    L = 6 * (s * s);
    System.out.println("HASIL LUAS PERMUKAAN KUBUS ADALAH " + L);
  }
  
  public void Volume() {
    V = s * s * s;
    System.out.println("HASIL VOLUME KUBUS ADALAH " + V);
  }
}
